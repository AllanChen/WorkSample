//
//  QRScanView.h
//  MShow
//
//  Created by it on 4/19/16.
//  Copyright © 2016 Allan.Chan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRScanView : UIView

- (instancetype)initWithScanRect:(CGRect)rect;

@end